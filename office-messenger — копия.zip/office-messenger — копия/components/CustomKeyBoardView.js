import { View, Text, KeyboardAvoidingView, ScrollView, Platform } from 'react-native'
import React from 'react'

const ios = Platform.ios =='ios'

export default function CustomKeyBoardView({children, inChat}) {
    let kavConfig={};
    let scrollViewConfig = {};
    if (inChat){
        kavConfig = {keyboardVerticalOffset:90};
        scrollViewConfig = {contentContainerStyle: {flex:1}};
    }
  return (
    <KeyboardAvoidingView
    behavior={ios?'padding':'height'}
    keyboardVerticalOffset={90}
    style={{flex:1}}
    {...kavConfig}
    >
        <ScrollView
        style={{flex:1}}
       {...scrollViewConfig}
        bounces={false}
        showsVerticalScrollIndicator={false}
        >
            {
                children
            }
        </ScrollView>
    </KeyboardAvoidingView>
  )
}