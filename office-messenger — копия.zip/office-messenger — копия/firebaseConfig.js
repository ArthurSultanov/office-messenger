// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
import {getReactNativePersistence, initializeAuth} from 'firebase/auth'
// Your web app's Firebase configuration
import AsyncStorage from "@react-native-async-storage/async-storage";
import {getFirestore, collection} from 'firebase/firestore'
const firebaseConfig = {
  apiKey: "AIzaSyCnTh0sFFn3nsSIFHaafXQ5nqVDfR4i0Ww",
  authDomain: "office-messenger-chat.firebaseapp.com",
  projectId: "office-messenger-chat",
  storageBucket: "office-messenger-chat.appspot.com",
  messagingSenderId: "379576381874",
  appId: "1:379576381874:web:8c4e58a999a8a85bb0f4ab"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = initializeAuth(app,{
    persistance: getReactNativePersistence(AsyncStorage)
});

export const db = getFirestore(app);
export const usersRef = collection(db, 'users');
export const roomRef = collection(db, 'rooms');